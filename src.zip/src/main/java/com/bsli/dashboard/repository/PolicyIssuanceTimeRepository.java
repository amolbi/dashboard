package com.bsli.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsli.dashboard.model.PolicyIssueTimeEntity;

public interface PolicyIssuanceTimeRepository extends JpaRepository<PolicyIssueTimeEntity, Integer>{

}
