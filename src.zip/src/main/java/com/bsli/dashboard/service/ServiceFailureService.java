package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.ServiceFailureEntity;
import com.bsli.dashboard.model.ServiceFailureResponse;
import com.bsli.dashboard.repository.ServiceFailureRepository;

@Service
public class ServiceFailureService {

	@Autowired
	private ServiceFailureRepository failureRepository;

	public ServiceFailureResponse getServicefailure(DashBoardRequest cardRequest) {

		List<ServiceFailureEntity> findAll = failureRepository.findAll();

		if (Optional.ofNullable(findAll).isPresent()) {
			ServiceFailureResponse failureResponse = new ServiceFailureResponse();
			failureResponse.setServiceFailures(findAll);
			return failureResponse;
		} else {
			throw new UserDefinedException(103, "Service Failure details are not available");
		}
	}
}