package com.bsli.dashboard.service;

import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.StatusCardEntity;
import com.bsli.dashboard.model.StatusCardResponse;
import com.bsli.dashboard.repository.StatusCardRepository;
import com.bsli.dashboard.repository.TStatusCardRepository;

@Service
public class StatusCardService {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private StatusCardRepository cardRepository;
	@Autowired
	private TStatusCardRepository tStatusCardRepository;
	


/* public StatusCardResponse getStatusCardDetails(StatusCardRequest cardRequest)
 {
 
 List<StatusCard> findBySearchCriteriaAndSearchValue = cardRepository.findBySearchCriteriaAndSearchValue(cardRequest.getSearchCriteria(),
 cardRequest.getSearchValue());
StatusCardResponse statusCardResponse = new StatusCardResponse();
statusCardResponse.setStatusCards(findBySearchCriteriaAndSearchValue);
	  return statusCardResponse; }*/
	 

	public StatusCardResponse getStatusCardDetails(DashBoardRequest cardRequest) {

//		List<StatusCardEntity> findAll = cardRepository.findAll();
//		List<TStatusCardEntity> findAllNew = tStatusCardRepository.findByChannel("EAPP");
		String channel = null, productCode=null, pendingKitty=null, fromDate=null, toDate=null;
		if("Product Type".equalsIgnoreCase(cardRequest.getSearchCriteria()))
				productCode = cardRequest.getSearchValue();
		if("Pending Kitty".equalsIgnoreCase(cardRequest.getSearchCriteria()))
			pendingKitty = cardRequest.getSearchValue();
		if("Channel".equalsIgnoreCase(cardRequest.getSearchCriteria()))
			channel = cardRequest.getSearchValue();
		
		if(!"".equalsIgnoreCase(cardRequest.getFromDate()))
			fromDate = cardRequest.getFromDate();
		if(!"".equalsIgnoreCase(cardRequest.getToDate()))
			toDate = cardRequest.getToDate();
	
		List<StatusCardEntity> findAll =  findData(channel, productCode, pendingKitty, fromDate, toDate);
		if (Optional.ofNullable(findAll).isPresent()) {
			StatusCardResponse statusCardResponse = new StatusCardResponse();
			statusCardResponse.setStatusCards(findAll);
			return statusCardResponse;
		} else {
			throw new UserDefinedException(104,"Status Card details are not available");
		}
	}
	
	public StatusCardResponse getCustom()
	{
		List<StatusCardEntity> findAll = cardRepository.find("Policy Created");
		if (Optional.ofNullable(findAll).isPresent()) 
		{
			StatusCardResponse statusCardResponse = new StatusCardResponse();
			statusCardResponse.setStatusCards(findAll);
			return statusCardResponse;
		} else {
			throw new UserDefinedException(104,"Status Card details are not available");
		}
	}
	
	public List<StatusCardEntity> findData(String channel, String productCode, String pendingKitty, String fromDate, String toDate) 
	{
		List<StatusCardEntity> findAll = new ArrayList<>();
		
        List prmtrsList = new ArrayList();
        prmtrsList.add(new SqlParameter(Types.VARCHAR));
        prmtrsList.add(new SqlParameter(Types.VARCHAR));
        prmtrsList.add(new SqlParameter(Types.VARCHAR));
        prmtrsList.add(new SqlParameter(Types.VARCHAR));
        prmtrsList.add(new SqlParameter(Types.VARCHAR));

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
        	CallableStatement callableStatement = connection.prepareCall("{call ui.GET_ALL_STATUS_CARDS(?,?,?,?,?)}");
        	callableStatement.setString(1, channel);
        	callableStatement.setString(2, productCode);
        	callableStatement.setString(3, pendingKitty);
        	callableStatement.setString(4, fromDate);
        	callableStatement.setString(5, toDate);
        	return callableStatement;
        }, prmtrsList);
        System.out.println("StatusCardService.findData()"+resultData);
        
        for(String key : resultData.keySet())
        {
        	ArrayList<Object> mm = (ArrayList<Object>) resultData.get(key);
        	
        	for(Object o : mm)
        	{
        		LinkedCaseInsensitiveMap<Object> cardMap =  (LinkedCaseInsensitiveMap<Object>) o;
        		StatusCardEntity cardEntity = new StatusCardEntity();
        		cardEntity.setName(String.valueOf(cardMap.get("TITLE")));
        		cardEntity.setColor(String.valueOf(cardMap.get("COLOR")));
        		cardEntity.setIcon(String.valueOf(cardMap.get("ICON")));
        		Long l = (Long) cardMap.get("COUNT");
        		cardEntity.setCount(l.intValue());
        		
        		findAll.add(cardEntity);
        	}
        }
        
        return findAll;
        
    }
	
}