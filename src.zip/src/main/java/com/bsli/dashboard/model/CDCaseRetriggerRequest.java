package com.bsli.dashboard.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CDCaseRetriggerRequest {

	private String appNumbers;

	public boolean isValid() {
		return null != this.appNumbers && null != this.appNumbers;
	}
}