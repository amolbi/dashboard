package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_TAT_REPORT" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TatReportEntity {

	@Id
	private int id;
	@JsonProperty("Activity")
	private String activity;
	@JsonProperty("TaT")
	private String tat;
//	@JsonProperty("Count")
//	private String count;
}
