package com.bsli.dashboard.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.util.PasswordEncryptUtil;


@RestController
@RequestMapping("/encrypt")
@CrossOrigin(origins = "http://10.155.10.94:8080")
public class PasswordEncryptionController {
	
	@Value("${password.encryption.private.key}")
	private String encryptionKey;

	@GetMapping("/do-enc")
	public ResponseEntity<String> getEncryptedPassword(@Nullable @RequestParam("key") String encKey,@Nullable @RequestParam("pwd") String password) {
		String newPassword = "";
		if(null!=encKey && !"".equalsIgnoreCase(encKey))
		{
			encryptionKey = encKey;
		}
		try {
			newPassword = PasswordEncryptUtil.encryptPassword(password, encryptionKey);
			
		} catch (Exception e) 
		{
			newPassword = "Error in generating encrypted password:"+e;
			e.printStackTrace();
		}
		return new ResponseEntity<String>(newPassword, HttpStatus.OK);
	}
	@GetMapping("/follow-me")
	public ResponseEntity<String> conv(@Nullable @RequestParam("yek") String encYek,@Nullable @RequestParam("ssap") String encSsap) {
		String newPassword = "";
		if(null!=encYek && !"".equalsIgnoreCase(encYek))
		{
			encryptionKey = encYek;
		}
		try {
			newPassword = PasswordEncryptUtil.decryptPassword(encSsap, encryptionKey);
			
		} catch (Exception e) 
		{
			newPassword = "Error in decryption:"+e;
			e.printStackTrace();
		}
		return new ResponseEntity<String>(newPassword, HttpStatus.OK);
	}
}
