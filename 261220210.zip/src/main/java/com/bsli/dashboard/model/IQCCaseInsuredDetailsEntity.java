package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_IQC_INSURED_DETAILS" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IQCCaseInsuredDetailsEntity {

	@Id
	private String caseId;
	private String clientidInsured;
	private String liDob;
	private String liFirstname;
	private String liGender;
	private String liLname;
	private String liMname;
	private String liMaritalstatus;
	private String liMobileno;
	private String liNationality;
	private String liOccupation;
	private String liPan;
	private String relationshipWithLi;
	private String liTitle;
	private String customernameLi;
	private String ageLi;
	private String genderLi;
	private String existingPolicyNo;
	private String previouspolicyno;
	private String annualIncome;
	private String parentSpouseIncome;
	private String liandproposer;
	private String pep;
//	private String form60Ind;

	//@JsonProperty("Remarks")
	//private String remarks;
}
