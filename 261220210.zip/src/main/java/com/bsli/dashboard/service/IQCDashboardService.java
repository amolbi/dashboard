package com.bsli.dashboard.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bsli.dashboard.model.CaseTrackerDetailsEntity;
import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.DashboardFilter;
import com.bsli.dashboard.model.IQCCMDownloadResponse;
import com.bsli.dashboard.model.IQCStatusCardEntity;
import com.bsli.dashboard.model.IQCStatusCardResponse;
import com.bsli.dashboard.model.ListIQCSTPKittyEntity;
import com.bsli.dashboard.model.ListIQCSTPKittyResponse;
import com.bsli.dashboard.repository.DashboardFilterRepository;
import com.bsli.dashboard.repository.IQCCaseInsuredDetailsRepository;
import com.bsli.dashboard.repository.IQCCasePlanDetailsRepository;
import com.bsli.dashboard.repository.IQCCaseProposerDetailsRepository;
import com.bsli.dashboard.repository.IQCCaseReqtDetailsRepository;
import com.bsli.dashboard.repository.IQCStatusCardRepository;
import com.bsli.dashboard.repository.ListIQCSTPKittyRepository;
import com.bsli.util.CMDownloadHelper;

@Service
public class IQCDashboardService {
	
	private final Logger LOGGER = LoggerFactory.getLogger(IQCDashboardService.class);
	
	@Value("${IQC_ALLOWED_CM_INDEX_CLASSES}")
	private String allowedIndexClasses;
	@Value("${CM_LIST_URL}")
	private String cmListURL;
	@Value("${CM_DOWNLOAD_URL}")
	private String cmDownloadURL;
	@Value("${SP_IQC_GET_ISURED_DETAILS}")
	private String spGetInsuredDetails;
	@Value("${IQC_ASSIGN_TO_USER_LIST}")
	private String queryAssignToDropdown;
	@Value("${IQC_LIST_ALL_REASSIGN_CASES}")
	private String queryListReAssignAllCases;
	@Value("${SP_IQC_DO_REASSIGN_CASES}")
	private String spDoRessignment;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private IQCStatusCardRepository iqcStatusCardRepository;
	
	@Autowired
	private ListIQCSTPKittyRepository listIQCSTPKittyRepository;
	
	@Autowired
	private IQCCaseInsuredDetailsRepository caseInsuredDetailsRepository;
	@Autowired
	private IQCCaseProposerDetailsRepository caseProposerDetailsRepository;
	@Autowired
	private IQCCasePlanDetailsRepository casePlanDetailsRepository;
	@Autowired
	private IQCCaseReqtDetailsRepository caseReqtDetailsRepository;
	@Autowired
	private DashboardFilterRepository dashboardFilterRepository;
	
	@Autowired
	private CaseTrackerService caseTrackerService;
	
	
	
	public IQCStatusCardResponse fetchAllCards()
	{
		List<IQCStatusCardEntity> listOfCards = iqcStatusCardRepository.findAll();
		IQCStatusCardResponse response = new IQCStatusCardResponse();
		LOGGER.info("fetchAllCards:"+listOfCards);
		if(Optional.ofNullable(listOfCards).isPresent())
		{
			response.setStatusCards(listOfCards);
		}
		
		return response;
	}
	
	public ListIQCSTPKittyResponse fetchAllIQCSTPKitty(String listType)
	{
		LOGGER.info("fetchAllIQCSTPKitty:"+listType);
		ListIQCSTPKittyResponse response = new ListIQCSTPKittyResponse();
		
		List<ListIQCSTPKittyEntity> list = null;
		
		if("ALL".equalsIgnoreCase(listType)){
			list = listIQCSTPKittyRepository.findAll();
		}else
			list = listIQCSTPKittyRepository.findTopByNumber();
		
		if(Optional.ofNullable(list).isPresent())
		{
			response.setIqcSTPKittyList(list);
		}
		
		
		return response;
	}
	
	public String fetchAssignToDropDown()
	{
		JSONArray returnJsonArray = new JSONArray();
		
		String queryOutput = executeQuery(queryAssignToDropdown);
		System.out.println("IQCDashboardService.fetchAssignToDropDown()"+queryOutput);
		if(null!=queryOutput 
				&& !"".equals(queryOutput))
		{
			try {
				returnJsonArray = new JSONArray(queryOutput);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnJsonArray.toString();
	}
	
	public String fetchAllListOfReASsignCases(String inputJSON)
	{
		JSONArray returnJsonArray = new JSONArray();
		try {

			JSONObject jObj = new JSONObject(inputJSON);
			
			String kitty = jObj.getString("kitty");
			
			if("ALL".equalsIgnoreCase(kitty))
			{
				//queryListReAssignAllCases = queryListReAssignAllCases;
			}
			else if(!"ALL".equalsIgnoreCase(kitty))
			{
				queryListReAssignAllCases = queryListReAssignAllCases + " AND IQC_CASE_TYPE = '"+kitty+"'";
			}
			
			queryListReAssignAllCases = queryListReAssignAllCases + " FOR JSON AUTO ) AS RESULT";
			
			String queryOutput = executeQuery(queryListReAssignAllCases);
			if(null!=queryOutput 
					&& !"".equals(queryOutput))
			{
				returnJsonArray = new JSONArray(queryOutput);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return returnJsonArray.toString();
	}
	
	public String doReassignCase(String inputJSON)
	{
		JSONArray returnJsonArray = new JSONArray();
		try {

			JSONObject jObj = new JSONObject(inputJSON);
			
			String caseIds = jObj.getString("caseId");
			String assignTo = jObj.getString("assignTo");
			String updatedBy = jObj.getString("loginUser");
			
			for(String caseId : caseIds.split(","))
			{
				List<String> queryOutput = doSPReassignment(caseId, assignTo, updatedBy, spDoRessignment);
				
				if(null!=queryOutput 
						&& !queryOutput.isEmpty())
				{
					for(String obj : queryOutput)
					{
						try 
						{
							JSONArray resultArray = new JSONArray(obj);
							for (int i = 0; i < resultArray.length(); i++) 
							{
								JSONObject jsonObject = resultArray.getJSONObject(i);
								returnJsonArray.put(jsonObject);
							}
						} 
						catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return returnJsonArray.toString();
	}
	
	public String fetchIQCCaseDetails(CaseTrackerRequest caseTrackerRequest)
	{
		LOGGER.info("fetchIQCCaseDetails:"+caseTrackerRequest);
		
//		IQCCaseDetailsResponse response = new IQCCaseDetailsResponse();
		JSONArray returnJsonArray = new JSONArray();
		
		if(null != caseTrackerRequest
				&& !"".equals(caseTrackerRequest.getCaseId()))
		{
//			List<IQCCaseInsuredDetailsEntity> caseInsuredDetailsEntity = 
//					caseInsuredDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			List<String> list =fetchIQCData(caseTrackerRequest.getCaseId(), spGetInsuredDetails);
			
			for(String obj : list)
			{
				try 
				{
					JSONArray resultArray = new JSONArray(obj);
					for (int i = 0; i < resultArray.length(); i++) 
					{
						JSONObject jsonObject = resultArray.getJSONObject(i);
						returnJsonArray.put(jsonObject);
					}
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			/*List<IQCCaseProposerDetailsEntity> caseProposerDetailsEntity = 
					caseProposerDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			List<IQCCasePlanDetailsEntity> casePlanDetailsEntity = 
					casePlanDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			List<IQCCaseReqtDetailsEntity> caseReqtDetailsEntity = 
					caseReqtDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			response.setInsuredDetails(caseInsuredDetailsEntity);
			response.setProposerDetails(caseProposerDetailsEntity);
			response.setPlanDetails(casePlanDetailsEntity);
			response.setReqtDetails(caseReqtDetailsEntity);*/
		}
		System.out.println("IQCDashboardService.fetchIQCCaseDetails():"+returnJsonArray);
		return returnJsonArray.toString();
		
	}
	

	
	public String getRequirementStatusDropdown() {
		JSONArray mainArray = new JSONArray();
		JSONObject reqtStatus = new JSONObject();

		List<DashboardFilter> planPolTyp = dashboardFilterRepository.findByCategory("REQT_STATUS");

		if (Optional.ofNullable(planPolTyp).isPresent()) {
			try {
				reqtStatus.put("option", "Reqt Status");
				JSONArray planPolTypeArray = new JSONArray();
				for(DashboardFilter f : planPolTyp)
				{
					JSONObject ob = new JSONObject();
					try {
						ob.put("value", f.getCode());
						ob.put("key",f.getDescription());
						planPolTypeArray.put(ob);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
				reqtStatus.put("suboption", planPolTypeArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(reqtStatus);
		}

		return mainArray.toString();
	}
	public String getMasterRequirementDropdown() {
		JSONArray mainArray = new JSONArray();
		JSONObject reqtStatus = new JSONObject();

		List<DashboardFilter> planPolTyp = dashboardFilterRepository.findByCategory("REQT_CD");

		if (Optional.ofNullable(planPolTyp).isPresent()) {
			try {
				reqtStatus.put("option", "Reqt");
				JSONArray planPolTypeArray = new JSONArray();
				for(DashboardFilter f : planPolTyp)
				{
					JSONObject ob = new JSONObject();
					try {
						ob.put("value", f.getCode());
						ob.put("key",f.getDescription());
						planPolTypeArray.put(ob);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
				reqtStatus.put("suboption", planPolTypeArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(reqtStatus);
		}

		return mainArray.toString();
	}

	public JSONArray fetchAllDocuments(CaseTrackerRequest caseTrackerRequest)
	{
		CaseTrackerDetailsEntity caseDetails = caseTrackerService.fetchCaseDetails(caseTrackerRequest);
		List<String> listIndexClasses = Arrays.asList(allowedIndexClasses.split(","));
		JSONArray finalCMOutputArray  = new JSONArray();
		try 
		{
			JSONArray inputIndexClassArray = new JSONArray();
			for(String indexClass : listIndexClasses)
			{
				JSONObject input = new JSONObject();
				input.put("AppNumber", caseDetails.getApplicationNumber());
				input.put("VERSION", "N");
				input.put("INDEX_CLASS", indexClass);

				inputIndexClassArray.put(input);
			}

			RestTemplate restTemplate = new RestTemplate();

			RequestEntity<String> requestEntity = RequestEntity.post(new URL(cmListURL).toURI())
					.contentType(MediaType.APPLICATION_JSON) 
					.body(inputIndexClassArray.toString()); 

			ResponseEntity<String> response = restTemplate.exchange(requestEntity, String.class);

			System.out.println("BB-"+response.getBody());

			if(null != response && 
					"200 OK".equalsIgnoreCase(response.getStatusCode().toString()))
			{
				JSONArray responseArray = new JSONArray(response.getBody());
				System.out.println("CC-"+responseArray);
				for (int i = 0, size = responseArray.length(); i < size; i++)
			    {
			      JSONObject objectInArray = responseArray.getJSONObject(i);
			      
			      if("000".equalsIgnoreCase(objectInArray.get("errorCode").toString()))
			      {
			    	  finalCMOutputArray.put(objectInArray);
			      }
			      
			    }
				System.out.println(finalCMOutputArray);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return finalCMOutputArray;

	}
	
	public IQCCMDownloadResponse downloadDocumentFromCM(String PID)
	{
		IQCCMDownloadResponse responseBean = new IQCCMDownloadResponse();
		try 
		{
			String contentType = "";
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(cmDownloadURL)
			        .queryParam("pid", PID);

			RestTemplate restTemplate = new RestTemplate();

			RequestEntity<String> requestEntity = RequestEntity.post(builder.buildAndExpand().toUri())
					.contentType(MediaType.APPLICATION_JSON) 
					.body(""); 

			ResponseEntity<Resource> response = restTemplate.exchange(requestEntity, Resource.class);
			
			System.out.println("AA"+response.getHeaders());
			
			for (Entry<String, List<String>> header : response.getHeaders().entrySet()) {
			    if(("Content-Type").equalsIgnoreCase(header.getKey()))
			    {
			    	contentType = header.getValue().get(0);
			    }
			}
			responseBean.setContentType(contentType);
			responseBean.setExtension(CMDownloadHelper.getExtensionFromContentType(contentType));
			responseBean.setInputStream(response.getBody().getInputStream());
			responseBean.setFileByteArray(getByteArrayFromInputStream(response.getBody().getInputStream()));
			responseBean.setStatus("200");
//			File file = new File("E:\\Test\\1.jpeg");
//			copyInputStreamToFile(response.getBody().getInputStream(), file);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responseBean;
	}

	private static void copyInputStreamToFile(InputStream inputStream, File file)
            throws IOException {
		
		int DEFAULT_BUFFER_SIZE = 8192;

        // append = false
        try (FileOutputStream outputStream = new FileOutputStream(file, false)) {
            int read;
            byte[] bytes = new byte[DEFAULT_BUFFER_SIZE];
            while ((read = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }
        }

    }
	private static byte[] getByteArrayFromInputStream(InputStream inputStream)
            throws IOException {
		
		byte[] buffer = new byte[8192];
	    int bytesRead;
	    ByteArrayOutputStream output = new ByteArrayOutputStream();
	    while ((bytesRead = inputStream.read(buffer)) != -1)
	    {
	        output.write(buffer, 0, bytesRead);
	    }
	    return output.toByteArray();

    }
	public List<String> fetchIQCData(String caseId, String storedProcName) 
	{
		List<String> findAll = new ArrayList<>();
		
        List prmtrsList = new ArrayList();
        prmtrsList.add(new SqlParameter(Types.BIGINT));

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
        	CallableStatement callableStatement = connection.prepareCall(storedProcName);
        	callableStatement.setInt(1, Integer.parseInt(caseId));
        	return callableStatement;
        }, prmtrsList);
        System.out.println("fetchIQCData:"+resultData);
        
        for(String key : resultData.keySet())
        {
        	ArrayList<Object> dbResultSet = (ArrayList<Object>) resultData.get(key);
        	
        	for(Object o : dbResultSet)
        	{
        		LinkedCaseInsensitiveMap<Object> dbRow =  (LinkedCaseInsensitiveMap<Object>) o;
        		for (String k : dbRow.keySet())
        		{
        			System.out.println("ResultSet Keys found:"+k);
        			findAll.add(dbRow.get(k).toString());
        	    }
//        		System.out.println(cardMap.get("insuredDetails"));
//        		System.out.println(cardMap.get("proposerDetails"));
        	}
        }
        
        return findAll;
        
    }
	
	public List<String> doSPReassignment(String caseId, String newOwner, String updatedBy, String storedProcName) 
	{
		List<String> findAll = new ArrayList<>();
		
        List prmtrsList = new ArrayList();
        prmtrsList.add(new SqlParameter(Types.BIGINT));
        prmtrsList.add(new SqlParameter(Types.NVARCHAR));
        prmtrsList.add(new SqlParameter(Types.NVARCHAR));

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
        	CallableStatement callableStatement = connection.prepareCall(storedProcName);
        	callableStatement.setInt(1, Integer.parseInt(caseId));
        	callableStatement.setString(2, (newOwner));
        	callableStatement.setString(3, (updatedBy));
        	return callableStatement;
        }, prmtrsList);
        System.out.println("doSPReassignment:"+resultData);
        
        for(String key : resultData.keySet())
        {
        	ArrayList<Object> dbResultSet = (ArrayList<Object>) resultData.get(key);
        	
        	for(Object o : dbResultSet)
        	{
        		LinkedCaseInsensitiveMap<Object> dbRow =  (LinkedCaseInsensitiveMap<Object>) o;
        		for (String k : dbRow.keySet())
        		{
        			System.out.println("ResultSet Keys found:"+k);
        			findAll.add(dbRow.get(k).toString());
        	    }
        	}
        }
        
        return findAll;
        
    }
	
	public String executeQuery(String sql)
	{

	    String streetName = (String) jdbcTemplate.queryForObject(
	            sql,String.class);

	    return streetName;
	}
}
