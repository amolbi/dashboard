package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.PendingKittyEntity;
import com.bsli.dashboard.model.PendingKittyResponse;
import com.bsli.dashboard.repository.PendingKittyRepository;

@Service
public class PendingKittyService {

	@Autowired
	private PendingKittyRepository kittyRepository;

	
	public PendingKittyResponse getPendingKitty(DashBoardRequest cardRequest) {

		List<PendingKittyEntity> findAll = kittyRepository.findTopByNumber();

		if (Optional.ofNullable(findAll).isPresent()) {
			PendingKittyResponse kittyResponse = new PendingKittyResponse();
			kittyResponse.setPendingKittyEntity(findAll);
			return kittyResponse;
		} else {
			throw new UserDefinedException(101, "No Pending Kitty details are available");
		}
	}
}
//QueryDSL -- can be used to create Dynamic Queries in Spring boot Projects


