package com.bsli.dashboard.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.PendingKittyResponse;
import com.bsli.dashboard.model.PolicyIssueTimeResponse;
import com.bsli.dashboard.model.ServiceFailureResponse;
import com.bsli.dashboard.model.StatusCardResponse;
import com.bsli.dashboard.model.TatReportResponse;
import com.bsli.dashboard.service.DashboardService;
import com.bsli.dashboard.service.PendingKittyService;
import com.bsli.dashboard.service.PolicyIssuanceTimeService;
import com.bsli.dashboard.service.ServiceFailureService;
import com.bsli.dashboard.service.StatusCardService;
import com.bsli.dashboard.service.TatReportService;

@RestController
@CrossOrigin(origins = "http://10.155.10.94:8080") //http://10.155.10.94:8080,http://liissuancewfuat.insideabc.com:8080
@RequestMapping("/dashboard")
public class DashboardController {

	private final Logger logger = LoggerFactory.getLogger(DashboardController.class);

	@Autowired
	private StatusCardService cardService;
	@Autowired
	private ServiceFailureService failureService;
	@Autowired
	private PolicyIssuanceTimeService issuanceService;
	@Autowired
	private TatReportService reportService;
	@Autowired
	private PendingKittyService kittyService;
	@Autowired
	private DashboardService dashboardService;

	@PostMapping("/status-card")
	public ResponseEntity<StatusCardResponse> getStatusCard(@RequestBody DashBoardRequest cardRequest) {
		logger.info("Status Card Service Called with Input -->" + cardRequest);
		return new ResponseEntity<StatusCardResponse>(cardService.getStatusCardDetails(cardRequest), HttpStatus.OK);
	}
	
	@PostMapping("/status-card-custom")
	public ResponseEntity<StatusCardResponse> getStatusCardCustom(@RequestBody DashBoardRequest cardRequest) {
		logger.info("Status Card Service Called with Input -->" + cardRequest);
		return new ResponseEntity<StatusCardResponse>(cardService.getCustom(), HttpStatus.OK);
	}

	@PostMapping("/service-failure")
	public ResponseEntity<ServiceFailureResponse> getServicefailure(@RequestBody DashBoardRequest cardRequest) {
		return new ResponseEntity<ServiceFailureResponse>(failureService.getServicefailure(cardRequest), HttpStatus.OK);
	}

	@PostMapping("/policy-issuance-time")
	public ResponseEntity<PolicyIssueTimeResponse> getPolicyIssuanceTime(@RequestBody DashBoardRequest cardRequest) {
		return new ResponseEntity<PolicyIssueTimeResponse>(issuanceService.getPolicyIssuanceTime(cardRequest),
				HttpStatus.OK);
	}

	@PostMapping("/tat-report")
	public ResponseEntity<TatReportResponse> getTatReport(@RequestBody DashBoardRequest cardRequest) {
		return new ResponseEntity<TatReportResponse>(reportService.getTatReport(cardRequest), HttpStatus.OK);
	}

	@PostMapping("/pending-kitty")
	public ResponseEntity<PendingKittyResponse> getPendingKitty(@RequestBody DashBoardRequest cardRequest) {
		return new ResponseEntity<PendingKittyResponse>(kittyService.getPendingKitty(cardRequest), HttpStatus.OK);
	}
	@PostMapping(path="/filter-options",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getFilterOption() {
		return new ResponseEntity<Object>(dashboardService.getFilterOptions(), HttpStatus.OK);
	}
}