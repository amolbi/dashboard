package com.bsli.util;

public class CMDownloadHelper {
	
	
	
	public static String getExtensionFromContentType(String cType){
		String extension = "";
		 if(cType.contains("tiff"))
		 {
			 extension = "tiff";
		 }
		 else if(cType.contains("pdf"))
		 {
			 extension = "pdf";
		 }
		 else if(cType.contains("jpg"))
		 {
			 extension = "jpg";
		 }
		 else if(cType.contains("jpeg"))
		 {
			 extension = "jpeg";
		 }
		 else if (cType.contains("bmp")) 
		 {
			 extension = "bmp";
		 }
		return extension;
		
	}
		

}
