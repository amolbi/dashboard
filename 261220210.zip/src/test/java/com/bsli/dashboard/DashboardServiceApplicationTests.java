package com.bsli.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
