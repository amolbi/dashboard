package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name= "V_UI_POLICY_ISSUANCE_TIME" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyIssueTimeEntity {

	@Id
	private int id;
	private String issuance;
	private String time;
	private String color;
}
