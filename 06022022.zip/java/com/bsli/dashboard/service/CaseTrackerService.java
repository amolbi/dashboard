package com.bsli.dashboard.service;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.CDCaseRetriggerResponse;
import com.bsli.dashboard.model.CDRetriggerModel;
import com.bsli.dashboard.model.CaseAuditLogsEntity;
import com.bsli.dashboard.model.CaseTimeTakenEntity;
import com.bsli.dashboard.model.CaseTrackerDetailsEntity;
import com.bsli.dashboard.model.CaseTrackerDetailsResponse;
import com.bsli.dashboard.model.CaseTrackerListRequest;
import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.CaseTrackerTableEntity;
import com.bsli.dashboard.model.CaseWSLogsEntity;
import com.bsli.dashboard.model.RetryServiceResponse;
import com.bsli.dashboard.repository.CaseAuditLogRepository;
import com.bsli.dashboard.repository.CaseTimeTakenRepository;
import com.bsli.dashboard.repository.CaseTrackerRepository;
import com.bsli.dashboard.repository.CaseTrackerTableRepository;
import com.bsli.dashboard.repository.CaseWSLogsRepository;
import com.bsli.util.PasswordEncryptUtil;
import com.bsli.util.RestServiceCallerHTTPS;

@Service
public class CaseTrackerService {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CaseTrackerRepository caseTrackerRepository;
	@Autowired
	private CaseTimeTakenRepository caseTimeTakenRepository;
	@Autowired
	private CaseAuditLogRepository caseAuditLogRepository;
	@Autowired
	private CaseTrackerTableRepository caseTrackerTableRepository;
	
	@Autowired
	private CaseWSLogsRepository caseWSLogsRepository;
	
	@Value("${baw.url}")
	private String bawURL;
	@Value("${baw.process.url}")
	private String bawProcessURL;
	@Value("${baw.user.id}")
	private String bawUserId;
	@Value("${baw.password}")
	private String bawPassword;
	@Value("${password.encryption.private.key}")
	private String inputKey;
	@Value("${SP_DO_CD_CASES}")
	private String spDoCDRetrigger;
	
	public CaseTrackerDetailsResponse getCaseDetails(CaseTrackerRequest caseTrackerRequest) {
		

		List<CaseTrackerDetailsEntity> caseTrackerDetails = caseTrackerRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseTrackerDetails).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTrackerDetails(caseTrackerDetails);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	public CaseTrackerDetailsResponse getCaseTImeTakenDetails(CaseTrackerRequest caseTrackerRequest) {

		List<CaseTimeTakenEntity> caseTimeTakenDetail = caseTimeTakenRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseTimeTakenDetail).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTimeTakenDetails(caseTimeTakenDetail);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	
	public CaseTrackerDetailsResponse getCaseAuditLogDetails(CaseTrackerRequest caseTrackerRequest) {

		List<CaseAuditLogsEntity> caseAuditLogsDetail = caseAuditLogRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseAuditLogsDetail).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseAuditLogsEntities(caseAuditLogsDetail);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	public CaseTrackerDetailsResponse getCaseTrackerTableDetails(CaseTrackerListRequest caseTrackerRequest) {
		
		List<CaseTrackerTableEntity> caseTrackerTableList = caseTrackerTableRepository.findAll();
		
		String listType = caseTrackerRequest.getListType();
		
		if("SERVICE_FAILURE_RSM".equalsIgnoreCase(listType))
		{
			
		}
		else if("PENDING".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.allPendingCases();
		}
		else if("VIEW_MORE_POLICY_CREATED".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePolicyCreatedList();
		}
		else if("VIEW_MORE_PENDING_RECIEPTING".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForRWSList();
		}
		else if("VIEW_MORE_PENDING_UW_DECISION".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForAURAList();
		}
		else if("VIEW_MORE_PENDING_POSIDEX_DECISION_(MODERATE)".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForPosidexDecisionList();
		}
		else if("VIEW_MORE_PENDING_IMAGE_QC".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForIQCDecisionList();
		}
		else if("VIEW_MORE_POLICY_ISSUED".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreAISList();
		}
		else if("VIEW_MORE_STUCK_CASES".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreStuckCasesList();
		}
		else if("VIEW_MORE_PENDING_PIVC".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreStuckPendingForPIVCList();
		}

		if (Optional.ofNullable(caseTrackerTableList).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTrackerTableEntities(caseTrackerTableList);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	
	public RetryServiceResponse doCaseRetryService(CaseTrackerRequest caseTrackerRequest) {
		
		List<CaseWSLogsEntity> caseWSLogsEntities = caseWSLogsRepository.findByCaseIdAndProcessCD(Integer.parseInt(caseTrackerRequest.getCaseId()),
				caseTrackerRequest.getCaseParam());
		if (Optional.ofNullable(caseWSLogsEntities).isPresent()) {
			String taskId="";
			for(CaseWSLogsEntity caseEntity : caseWSLogsEntities)
			{
				taskId = caseEntity.getLogKeyId_1();
			}
			if(!"".equals(taskId))
			{
				taskId = taskId.split("\\.")[1];
				
//				String url = "https://bawwfuat.absli.com/rest/bpm/wle/v1/task/"+taskId+"?action=finish&parts=all";
				
				String url = bawURL.replace("$$TASK_ID$$", taskId);
				
				RestServiceCallerHTTPS https = new RestServiceCallerHTTPS();
				Boolean isCallDone = https.callHTTPSURL(url, null, bawUserId, 
						PasswordEncryptUtil.decryptPassword(bawPassword, inputKey));
				
				if(isCallDone)
				{
					List<CaseTrackerTableEntity> caseTrackerTableList = caseTrackerTableRepository.findAll();

					if (Optional.ofNullable(caseTrackerTableList).isPresent()) {
						RetryServiceResponse response = new RetryServiceResponse();
						response.setErrorCode(00);
						response.setErrorMessage("Case retriggered successfully.");
						return response;
					}else {
						throw new UserDefinedException(102,"Data not found!");
					}
				}else {
					throw new UserDefinedException(102,"Data not found!");
				}
					
			}else {
				throw new UserDefinedException(102,"Data not found!");
			}
			
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
		
		
	}
	
	public CDCaseRetriggerResponse doCDCaseRetrigger(String appNumbers)
	{
		System.out.println("CaseTrackerService.doCDCaseRetrigger()"+appNumbers);
		
		List<String> appNumberArrayList = Pattern.compile(",")
                .splitAsStream(appNumbers)
                .collect(Collectors.toList());
		System.out.println(appNumberArrayList);
		
		RestServiceCallerHTTPS https = new RestServiceCallerHTTPS();
		List<CDRetriggerModel> list = new ArrayList<CDRetriggerModel>();
		
		for(String appNumebr : appNumberArrayList)
		{
			CDRetriggerModel n1 = new CDRetriggerModel();
			
			List<String> listOfURL = doSPCDRetrigger(appNumebr, spDoCDRetrigger);
			
			if(listOfURL.isEmpty())
			{
				n1.setRemarks("Not available in BPM.");
				n1.setStatus("No");
				n1.setAppNo(appNumebr);
				n1.setCategory("Non-BPM");
			}
			
			for(String cdURL : listOfURL)
			{
				System.out.println("cdURL:"+cdURL);
				try {
					Map<String, String>  mapOfQueryParams = splitQueryParamsFromURL(cdURL);
					
//					String newCDURL = bawProcessURL + "?";
					
					StringBuilder newCDURL = new StringBuilder();
					newCDURL.append(bawProcessURL);
					for(Map.Entry<String, String> query: mapOfQueryParams.entrySet()) 
					{
						newCDURL.append( "&" + query.getKey()+"="+encodeValue(query.getValue()));
				    }
					
					System.out.println("MapOfQueryParams:-"+mapOfQueryParams);
					Boolean isCallDone = https.callHTTPSURL(newCDURL.toString(), null, bawUserId, 
							PasswordEncryptUtil.decryptPassword(bawPassword, inputKey));
					
					if(isCallDone)
					{
						n1.setRemarks("Processed Successfully");
						n1.setStatus("Yes");
						n1.setAppNo(appNumebr);
						n1.setCategory("BPM");
					}else{
						n1.setRemarks("Processing failed.");
						n1.setStatus("Yes");
						n1.setAppNo(appNumebr);
						n1.setCategory("BPM");
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			
			list.add(n1);
		}
		
		CDCaseRetriggerResponse response = new CDCaseRetriggerResponse();

		System.out.println(list);
		
		if (Optional.ofNullable(list).isPresent()) {
			
			response.setCdCaseRetriggerResponseList(list);
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}

		return response;
	}
	public CaseTrackerDetailsEntity fetchCaseDetails(CaseTrackerRequest caseTrackerRequest)
	{
		CaseTrackerDetailsEntity caseDetailsReturn = null;
		List<CaseTrackerDetailsEntity> caseTrackerDetails = caseTrackerRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseTrackerDetails).isPresent()) {
			for(CaseTrackerDetailsEntity caseDetails : caseTrackerDetails)
			{
				caseDetailsReturn = caseDetails;
			}
			System.out.println(caseDetailsReturn);
		}
		return caseDetailsReturn;
		
	}
	public List<String> doSPCDRetrigger(String appNumber, String storedProcName) 
	{
		List<String> findAll = new ArrayList<>();
		
        List prmtrsList = new ArrayList();
        prmtrsList.add(new SqlParameter(Types.NVARCHAR));

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
        	CallableStatement callableStatement = connection.prepareCall(storedProcName);
        	callableStatement.setString(1, (appNumber));
        	return callableStatement;
        }, prmtrsList);
        System.out.println("doSPCDRetrigger:"+resultData);
        
        for(String key : resultData.keySet())
        {
        	ArrayList<Object> dbResultSet = (ArrayList<Object>) resultData.get(key);
        	System.out.println("dbResultSet-"+dbResultSet);
        	for(Object o : dbResultSet)
        	{
        		LinkedCaseInsensitiveMap<Object> dbRow =  (LinkedCaseInsensitiveMap<Object>) o;
        		System.out.println("dbRow-"+dbRow);
        		for (String k : dbRow.keySet())
        		{
        			System.out.println("ResultSet Keys found:"+k+"::Value-"+dbRow.get(k).toString());
        			if("MESSAGE".equalsIgnoreCase(k))
        			{
        				findAll.add(dbRow.get(k).toString());
        			}
        	    }
        	}
        }
        
        return findAll;
        
    }
	
	public static Map<String, String> splitQueryParamsFromURL(String strUrl) throws UnsupportedEncodingException, MalformedURLException {
		 URL url = new URL(strUrl);
	    Map<String, String> query_pairs = new LinkedHashMap<String, String>();
	    String query = url.getQuery();
	    String[] pairs = query.split("&");
	    for (String pair : pairs) {
	        int idx = pair.indexOf("=");
	        query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
	    }
	    return query_pairs;
	}
	private String encodeValue(String value) throws Exception{
	    return URLEncoder.encode(value, StandardCharsets.UTF_8.toString()).toString();
	}
}
