package com.bsli.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsli.dashboard.model.ServiceFailureEntity;

public interface ServiceFailureRepository extends JpaRepository<ServiceFailureEntity, Integer>{
}
