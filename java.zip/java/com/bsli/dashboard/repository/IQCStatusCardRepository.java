package com.bsli.dashboard.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.bsli.dashboard.model.IQCStatusCardEntity;

public interface IQCStatusCardRepository extends JpaRepository<IQCStatusCardEntity, Integer> {


}