package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.DashboardFilter;

public interface DashboardFilterRepository extends JpaRepository<DashboardFilter, String>
{
	@Query(value="SELECT description,code,category FROM UI.V_LOOKUP_VALUES p WHERE category = LOWER(:category)",nativeQuery=true)
	public List<DashboardFilter> findByCategory(@Param("category") String category);
	
}
