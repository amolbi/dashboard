package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_IQC_PLAN_DETAILS" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IQCCasePlanDetailsEntity {

	@Id
	private String caseId;
	private String planId;
	private String bsliCode;
	private String planTypeName;
	private String planCvgTyp;
	private String planRiderTyp;
	//@JsonProperty("Remarks")
	//private String remarks;
}
