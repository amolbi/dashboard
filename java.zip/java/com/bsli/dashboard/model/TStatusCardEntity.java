package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "T_STATUS_CARD" , schema = "dbo")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TStatusCardEntity {

	@Id
	private int id;
	private String title;
	private int count;
	private String color;
	private String icon;
}
