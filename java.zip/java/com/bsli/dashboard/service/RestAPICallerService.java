package com.bsli.dashboard.service;

import java.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.util.RestServiceCallerHTTPS;

@Service
public class RestAPICallerService 
{

//	@Autowired
//	private DashboardFilterRepository dashboardFilterRepository;
	
	
	public void makeApiCall(CaseTrackerRequest caseTrackerRequest)
	{ 
		final String uri = "https://bawwfuat.absli.com/rest/bpm/wle/v1/task/109363132?action=finish&parts=all";

		JSONObject jsonResponse = null;
		try 
		{
//			List<DashboardFilter> allESB_URLs = dashboardFilterRepository.findByCategory("ESB_URL_BAW");
			
			if("Check_Payment_Ack_Process".equalsIgnoreCase(caseTrackerRequest.getCaseParam()))
			{
				
			}

			RestTemplate restTemplate = new RestTemplate();
			System.out.println("input:::"+caseTrackerRequest);

			String reqBody = "{  \"source\": \"4170703531\",  \"CaseID\": \""+caseTrackerRequest.getCaseId()+"\" }";
			JSONObject req = new JSONObject(reqBody);
			System.out.println("RestAPICallerService.makeApiCall():::"+req);
			
			String result = restTemplate.postForObject(uri, reqBody.getBytes(), String.class);

			jsonResponse = new JSONObject(result);
			System.out.println(jsonResponse);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	public void callRestSSLService(CaseTrackerRequest caseTrackerRequest)
	{
		 
		final String uri = "https://bawwfuat.absli.com/rest/bpm/wle/v1/task/109363132?action=finish&parts=all";

		JSONObject jsonResponse = null;
		try 
		{
//			List<DashboardFilter> allESB_URLs = dashboardFilterRepository.findByCategory("ESB_URL_BAW");
			
			if("Check_Payment_Ack_Process".equalsIgnoreCase(caseTrackerRequest.getCaseParam()))
			{
				
			}

			RestTemplate restTemplate = new RestTemplate();
			System.out.println("input:::"+caseTrackerRequest);

			String reqBody = "{  \"source\": \"4170703531\",  \"CaseID\": \""+caseTrackerRequest.getCaseId()+"\" }";
			JSONObject req = new JSONObject(reqBody);
			System.out.println("RestAPICallerService.makeApiCall():::"+req);
			
//			String url = "https://jsonplaceholder.typicode.com/posts";

		    // create auth credentials
		    String authStr = "inos006500:Amol@6500";
		    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

		    // create headers
		    HttpHeaders headers = new HttpHeaders();
		    headers.add("Authorization", "Basic " + base64Creds);

		    // create request
		    HttpEntity request = new HttpEntity(headers);

		    // make a request
		    ResponseEntity<String> response = new RestTemplate().exchange(uri, HttpMethod.POST, request, String.class);

		    // get JSON response
		    String json = response.getBody();

			jsonResponse = new JSONObject(json);
			System.out.println(jsonResponse);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	
	}
	
	public void doCallService(CaseTrackerRequest caseTrackerRequest)
	{
		String url = "https://bawwfuat.absli.com/rest/bpm/wle/v1/task/110756976?action=finish&parts=all";
		
		
		
		RestServiceCallerHTTPS https = new RestServiceCallerHTTPS();
		https.callHTTPSURL(url, null, "inos006500", "Amol@6500");
	}
	
	
		/*HttpHeaders createHeaders(String username, String password){
		   return new HttpHeaders() {{
		         String auth = username + ":" + password;
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
		}*/
}
