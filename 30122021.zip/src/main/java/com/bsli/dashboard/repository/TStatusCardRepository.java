package com.bsli.dashboard.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.TStatusCardEntity;

public interface TStatusCardRepository extends JpaRepository<TStatusCardEntity, Integer> {

	/*public void getCaller()
	{
		String sql="execute Procedure_Name ?";
		Object search[]={Id};
		List<TStatusCardEntity> client=jdbcTemplateObject.query(sql,search,new 
				TStatusCardEntity());
	}
	
	*/
	
	@Query(value = "CALL GET_ALL_STATUS_CARDS(:IN_CHANNEL);", nativeQuery = true)
    public List<TStatusCardEntity> findByChannel(@Param("IN_CHANNEL") String channel);

}