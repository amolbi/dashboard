package com.bsli.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseTrackerListRequest {

	private String listType;

	public boolean isValid() {
		return null != this.listType && null != this.listType;
	}
	
}
