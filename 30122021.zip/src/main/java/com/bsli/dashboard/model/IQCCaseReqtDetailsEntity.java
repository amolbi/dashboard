package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_IQC_CASE_REQ_DETAILS", schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IQCCaseReqtDetailsEntity {

	@Id
	private String id;
	private String caseId;
	private String reqtCd;
	private String reqtStatus;
	private String reqtTxt;
	private String remarks;
	private String reqCategory;
}
