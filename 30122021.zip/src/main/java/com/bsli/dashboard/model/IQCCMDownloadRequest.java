package com.bsli.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IQCCMDownloadRequest {

	private String pid;

	public boolean isValid() {
		return null != this.pid && null != this.pid;
	}
	
}
