package com.bsli.dashboard.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CDRetriggerModel {

	@JsonProperty("Application Number")
	private String appNo;
	@JsonProperty("Category")
	private String category;
	@JsonProperty("Processing Status")
	private String status;
	@JsonProperty("Remarks")
	private String remarks;
}
