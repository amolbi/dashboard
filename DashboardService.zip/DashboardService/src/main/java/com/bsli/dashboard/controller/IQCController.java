package com.bsli.dashboard.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.IQCCaseDetailsResponse;
import com.bsli.dashboard.model.IQCCaseReqtDetailsRequestObject;
import com.bsli.dashboard.model.IQCStatusCardResponse;
import com.bsli.dashboard.model.ListIQCSTPKittyResponse;
import com.bsli.dashboard.service.IQCDashboardService;

@RestController
@RequestMapping("/iqc")
@CrossOrigin(origins = "http://10.155.10.94:8080")
public class IQCController {
	private final Logger logger = LoggerFactory.getLogger(DashboardController.class);

	@Autowired
	private IQCDashboardService iqcDashboardService;
	
	@PostMapping("/status-card")
	public ResponseEntity<IQCStatusCardResponse> getStatusCard(@RequestBody DashBoardRequest cardRequest) {
		logger.info("IQC Status Card Service Called with Input -->" + cardRequest);
		return new ResponseEntity<IQCStatusCardResponse>(iqcDashboardService.fetchAllCards(), HttpStatus.OK);
	}
	
	@PostMapping("/list-stp-kitty")
	public ResponseEntity<ListIQCSTPKittyResponse> getSTPKitty(@RequestParam("ListType") String listType) {
		logger.info("List STP Kitty Service Called with Input -->" + listType);
		return new ResponseEntity<ListIQCSTPKittyResponse>(iqcDashboardService.fetchAllIQCSTPKitty(listType), HttpStatus.OK);
	}
	
	@PostMapping("/open-iqc-case")
	public ResponseEntity<IQCCaseDetailsResponse> fetchCaseDetails(@RequestBody CaseTrackerRequest caseTrackerRequest) {
		return new ResponseEntity<IQCCaseDetailsResponse>(iqcDashboardService.fetchIQCCaseDetails(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping(path="/iqc-reqt-decision-list",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getReqtStatusList() {
		return new ResponseEntity<Object>(iqcDashboardService.getRequirementStatusDropdown(), HttpStatus.OK);
	}
	
	@PostMapping(path="/iqc-reqt-list",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getMasterRequirementList() {
		return new ResponseEntity<Object>(iqcDashboardService.getMasterRequirementDropdown(), HttpStatus.OK);
	}
	
	@PostMapping("/update-iqc-reqt")
	public ResponseEntity<String> updateCaseDetails
	(@RequestBody IQCCaseReqtDetailsRequestObject reqtUpdateObj) 
	{
		logger.info(""+reqtUpdateObj);
		return new ResponseEntity<String>("", HttpStatus.OK);
	}
	
}
