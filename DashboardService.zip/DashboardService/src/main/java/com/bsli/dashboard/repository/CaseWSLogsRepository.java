package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.CaseWSLogsEntity;

public interface CaseWSLogsRepository extends JpaRepository<CaseWSLogsEntity, Integer>
{
	@Query(value="SELECT top 1 * FROM T_CASE_WS_LOGS WHERE CASE_ID=:caseId AND PROCESS_CD=:processCd AND LOG_KEY_ID_1 IS NOT NULL ORDER BY CREATED_DT DESC",nativeQuery=true)
	public List<CaseWSLogsEntity> findByCaseIdAndProcessCD(@Param("caseId") int caseId, @Param("processCd") String processCd);
	
}
