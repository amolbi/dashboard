package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.DashboardFilter;
import com.bsli.dashboard.model.IQCCaseDetailsResponse;
import com.bsli.dashboard.model.IQCCaseInsuredDetailsEntity;
import com.bsli.dashboard.model.IQCCasePlanDetailsEntity;
import com.bsli.dashboard.model.IQCCaseProposerDetailsEntity;
import com.bsli.dashboard.model.IQCCaseReqtDetailsEntity;
import com.bsli.dashboard.model.IQCStatusCardEntity;
import com.bsli.dashboard.model.IQCStatusCardResponse;
import com.bsli.dashboard.model.ListIQCSTPKittyEntity;
import com.bsli.dashboard.model.ListIQCSTPKittyResponse;
import com.bsli.dashboard.repository.DashboardFilterRepository;
import com.bsli.dashboard.repository.IQCCaseInsuredDetailsRepository;
import com.bsli.dashboard.repository.IQCCasePlanDetailsRepository;
import com.bsli.dashboard.repository.IQCCaseProposerDetailsRepository;
import com.bsli.dashboard.repository.IQCCaseReqtDetailsRepository;
import com.bsli.dashboard.repository.IQCStatusCardRepository;
import com.bsli.dashboard.repository.ListIQCSTPKittyRepository;

@Service
public class IQCDashboardService {
	
	private final Logger LOGGER = LoggerFactory.getLogger(IQCDashboardService.class);
	
	@Autowired
	private IQCStatusCardRepository iqcStatusCardRepository;
	
	@Autowired
	private ListIQCSTPKittyRepository listIQCSTPKittyRepository;
	
	@Autowired
	private IQCCaseInsuredDetailsRepository caseInsuredDetailsRepository;
	@Autowired
	private IQCCaseProposerDetailsRepository caseProposerDetailsRepository;
	@Autowired
	private IQCCasePlanDetailsRepository casePlanDetailsRepository;
	@Autowired
	private IQCCaseReqtDetailsRepository caseReqtDetailsRepository;
	@Autowired
	private DashboardFilterRepository dashboardFilterRepository;
	
	
	public IQCStatusCardResponse fetchAllCards()
	{
		List<IQCStatusCardEntity> listOfCards = iqcStatusCardRepository.findAll();
		IQCStatusCardResponse response = new IQCStatusCardResponse();
		LOGGER.info("fetchAllCards:"+listOfCards);
		if(Optional.ofNullable(listOfCards).isPresent())
		{
			response.setStatusCards(listOfCards);
		}
		
		return response;
	}
	
	public ListIQCSTPKittyResponse fetchAllIQCSTPKitty(String listType)
	{
		LOGGER.info("fetchAllIQCSTPKitty:"+listType);
		ListIQCSTPKittyResponse response = new ListIQCSTPKittyResponse();
		
		List<ListIQCSTPKittyEntity> list = null;
		
		if("ALL".equalsIgnoreCase(listType)){
			list = listIQCSTPKittyRepository.findAll();
		}else
			list = listIQCSTPKittyRepository.findTopByNumber();
		
		if(Optional.ofNullable(list).isPresent())
		{
			response.setIqcSTPKittyList(list);
		}
		
		
		return response;
	}
	
	public IQCCaseDetailsResponse fetchIQCCaseDetails(CaseTrackerRequest caseTrackerRequest)
	{
		LOGGER.info("fetchIQCCaseDetails:"+caseTrackerRequest);
		
		IQCCaseDetailsResponse response = new IQCCaseDetailsResponse();
		
		if(null != caseTrackerRequest
				&& !"".equals(caseTrackerRequest.getCaseId()))
		{
			List<IQCCaseInsuredDetailsEntity> caseInsuredDetailsEntity = 
					caseInsuredDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			List<IQCCaseProposerDetailsEntity> caseProposerDetailsEntity = 
					caseProposerDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			List<IQCCasePlanDetailsEntity> casePlanDetailsEntity = 
					casePlanDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			List<IQCCaseReqtDetailsEntity> caseReqtDetailsEntity = 
					caseReqtDetailsRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));
			
			response.setInsuredDetails(caseInsuredDetailsEntity);
			response.setProposerDetails(caseProposerDetailsEntity);
			response.setPlanDetails(casePlanDetailsEntity);
			response.setReqtDetails(caseReqtDetailsEntity);
		}
		
		return response;
		
	}
	

	
	public String getRequirementStatusDropdown() {
		JSONArray mainArray = new JSONArray();
		JSONObject reqtStatus = new JSONObject();

		List<DashboardFilter> planPolTyp = dashboardFilterRepository.findByCategory("REQT_STATUS");

		if (Optional.ofNullable(planPolTyp).isPresent()) {
			try {
				reqtStatus.put("option", "Reqt Status");
				JSONArray planPolTypeArray = new JSONArray();
				for(DashboardFilter f : planPolTyp)
				{
					JSONObject ob = new JSONObject();
					try {
						ob.put("value", f.getCode());
						ob.put("key",f.getDescription());
						planPolTypeArray.put(ob);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
				reqtStatus.put("suboption", planPolTypeArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(reqtStatus);
		}

		return mainArray.toString();
	}
	public String getMasterRequirementDropdown() {
		JSONArray mainArray = new JSONArray();
		JSONObject reqtStatus = new JSONObject();

		List<DashboardFilter> planPolTyp = dashboardFilterRepository.findByCategory("REQT_CD");

		if (Optional.ofNullable(planPolTyp).isPresent()) {
			try {
				reqtStatus.put("option", "Reqt");
				JSONArray planPolTypeArray = new JSONArray();
				for(DashboardFilter f : planPolTyp)
				{
					JSONObject ob = new JSONObject();
					try {
						ob.put("value", f.getCode());
						ob.put("key",f.getDescription());
						planPolTypeArray.put(ob);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
				reqtStatus.put("suboption", planPolTypeArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(reqtStatus);
		}

		return mainArray.toString();
	}


}
