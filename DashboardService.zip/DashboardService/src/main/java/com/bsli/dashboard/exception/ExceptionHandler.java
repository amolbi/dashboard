package com.bsli.dashboard.exception;

import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bsli.dashboard.model.ErrorResponse;

@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {

	@org.springframework.web.bind.annotation.ExceptionHandler(UserDefinedException.class)
	public final ResponseEntity<ErrorResponse> UserDefinedException(UserDefinedException exception) {

		return new ResponseEntity<ErrorResponse>(
				new ErrorResponse(exception.getErrorCode(), exception.getErrorMessage()),
				HttpStatus.EXPECTATION_FAILED);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> AllException(Exception exception) {

		exception.printStackTrace();
		return new ResponseEntity<ErrorResponse>(new ErrorResponse(106, exception.getMessage()),
				HttpStatus.EXPECTATION_FAILED);
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(SQLException.class)
	public final ResponseEntity<ErrorResponse> AllException(SQLException exception) {

		exception.printStackTrace();
		return new ResponseEntity<ErrorResponse>(new ErrorResponse(106, exception.getMessage()),
				HttpStatus.EXPECTATION_FAILED);
	}
}