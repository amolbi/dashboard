package com.bsli.dashboard.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.StatusCardEntity;

public interface StatusCardRepository extends JpaRepository<StatusCardEntity, Integer> {

	@Query(value="SELECT ID,NAME,COUNT,COLOR,ICON,CHANNEL,PRODUCT_TYPE,FRESH_INTRO_CARRYFOWARD,BPM_KITTY,ZONE,REGION,ZM_OPS,SM_OPS,ONLINE_OFFLINE FROM UI.V_UI_GET_STATUS_CARDS p WHERE name = LOWER(:name)",nativeQuery=true)
    public List<StatusCardEntity> find(@Param("name") String name);

}