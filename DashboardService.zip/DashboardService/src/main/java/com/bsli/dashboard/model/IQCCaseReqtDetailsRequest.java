package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IQCCaseReqtDetailsRequest {

	private String id;
	private String caseId;
	private String reqtCd;
	private String reqtStatus;
	private String reqtTxt;
	private String remarks;
	private String reqCategory;
}
