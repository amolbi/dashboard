package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_GET_STATUS_CARDS" , schema = "UI")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StatusCardEntity {

	@Id
	private int id;
	private String name;
	private int count;
	private String color;
	private String icon;
	private String zone;
    private String channel;
}
