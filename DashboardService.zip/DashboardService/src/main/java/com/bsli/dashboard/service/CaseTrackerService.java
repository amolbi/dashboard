package com.bsli.dashboard.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.CDCaseRetriggerResponse;
import com.bsli.dashboard.model.CDRetriggerModel;
import com.bsli.dashboard.model.CaseAuditLogsEntity;
import com.bsli.dashboard.model.CaseTimeTakenEntity;
import com.bsli.dashboard.model.CaseTrackerDetailsEntity;
import com.bsli.dashboard.model.CaseTrackerDetailsResponse;
import com.bsli.dashboard.model.CaseTrackerListRequest;
import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.CaseTrackerTableEntity;
import com.bsli.dashboard.model.CaseWSLogsEntity;
import com.bsli.dashboard.model.RetryServiceResponse;
import com.bsli.dashboard.repository.CaseAuditLogRepository;
import com.bsli.dashboard.repository.CaseTimeTakenRepository;
import com.bsli.dashboard.repository.CaseTrackerRepository;
import com.bsli.dashboard.repository.CaseTrackerTableRepository;
import com.bsli.dashboard.repository.CaseWSLogsRepository;
import com.bsli.util.RestServiceCallerHTTPS;

@Service
public class CaseTrackerService {
	@Autowired
	private CaseTrackerRepository caseTrackerRepository;
	@Autowired
	private CaseTimeTakenRepository caseTimeTakenRepository;
	@Autowired
	private CaseAuditLogRepository caseAuditLogRepository;
	@Autowired
	private CaseTrackerTableRepository caseTrackerTableRepository;
	
	@Autowired
	private CaseWSLogsRepository caseWSLogsRepository;
	
	public CaseTrackerDetailsResponse getCaseDetails(CaseTrackerRequest caseTrackerRequest) {
		

		List<CaseTrackerDetailsEntity> caseTrackerDetails = caseTrackerRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseTrackerDetails).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTrackerDetails(caseTrackerDetails);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	public CaseTrackerDetailsResponse getCaseTImeTakenDetails(CaseTrackerRequest caseTrackerRequest) {

		List<CaseTimeTakenEntity> caseTimeTakenDetail = caseTimeTakenRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseTimeTakenDetail).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTimeTakenDetails(caseTimeTakenDetail);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	
	public CaseTrackerDetailsResponse getCaseAuditLogDetails(CaseTrackerRequest caseTrackerRequest) {

		List<CaseAuditLogsEntity> caseAuditLogsDetail = caseAuditLogRepository.findByCaseIdCustom(Integer.parseInt(caseTrackerRequest.getCaseId()));

		if (Optional.ofNullable(caseAuditLogsDetail).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseAuditLogsEntities(caseAuditLogsDetail);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	public CaseTrackerDetailsResponse getCaseTrackerTableDetails(CaseTrackerListRequest caseTrackerRequest) {
		
		List<CaseTrackerTableEntity> caseTrackerTableList = caseTrackerTableRepository.findAll();
		
		String listType = caseTrackerRequest.getListType();
		
		if("SERVICE_FAILURE_RSM".equalsIgnoreCase(listType))
		{
			
		}
		else if("PENDING".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.allPendingCases();
		}
		else if("VIEW_MORE_POLICY_CREATED".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePolicyCreatedList();
		}
		else if("VIEW_MORE_PENDING_RECIEPTING".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForRWSList();
		}
		else if("VIEW_MORE_PENDING_UW_DECISION".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForAURAList();
		}
		else if("VIEW_MORE_PENDING_POSIDEX_DECISION_(MODERATE)".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForPosidexDecisionList();
		}
		else if("VIEW_MORE_PENDING_IMAGE_QC".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMorePendingForIQCDecisionList();
		}
		else if("VIEW_MORE_POLICY_ISSUED".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreAISList();
		}
		else if("VIEW_MORE_STUCK_CASES".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreStuckCasesList();
		}
		else if("VIEW_MORE_PENDING_PIVC".equalsIgnoreCase(listType))
		{
			caseTrackerTableList = caseTrackerTableRepository.viewMoreStuckPendingForPIVCList();
		}

		if (Optional.ofNullable(caseTrackerTableList).isPresent()) {
			CaseTrackerDetailsResponse response = new CaseTrackerDetailsResponse();
			response.setCaseTrackerTableEntities(caseTrackerTableList);
			return response;
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
	}
	
	public RetryServiceResponse doCaseRetryService(CaseTrackerRequest caseTrackerRequest) {
		
		List<CaseWSLogsEntity> caseWSLogsEntities = caseWSLogsRepository.findByCaseIdAndProcessCD(Integer.parseInt(caseTrackerRequest.getCaseId()),
				caseTrackerRequest.getCaseParam());
		if (Optional.ofNullable(caseWSLogsEntities).isPresent()) {
			String taskId="";
			for(CaseWSLogsEntity caseEntity : caseWSLogsEntities)
			{
				taskId = caseEntity.getLogKeyId_1();
			}
			if(!"".equals(taskId))
			{
				taskId = taskId.split("\\.")[1];
				
				String url = "https://bawwfuat.absli.com/rest/bpm/wle/v1/task/"+taskId+"?action=finish&parts=all";
				
				RestServiceCallerHTTPS https = new RestServiceCallerHTTPS();
				Boolean isCallDone = https.callHTTPSURL(url, null, "inos006500", "Absli$2021");
				if(isCallDone)
				{
					List<CaseTrackerTableEntity> caseTrackerTableList = caseTrackerTableRepository.findAll();

					if (Optional.ofNullable(caseTrackerTableList).isPresent()) {
						RetryServiceResponse response = new RetryServiceResponse();
						response.setErrorCode(00);
						response.setErrorMessage("Case retriggered successfully.");
						return response;
					}else {
						throw new UserDefinedException(102,"Data not found!");
					}
				}else {
					throw new UserDefinedException(102,"Data not found!");
				}
					
			}else {
				throw new UserDefinedException(102,"Data not found!");
			}
			
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}
		
		
		
	}
	
	public CDCaseRetriggerResponse doCDCaseRetrigger(String appNumbers)
	{
		System.out.println("CaseTrackerService.doCDCaseRetrigger()"+appNumbers);
		
		List<String> appNumberArrayList = Pattern.compile(",")
                .splitAsStream(appNumbers)
                .collect(Collectors.toList());
		System.out.println(appNumberArrayList);
		
		List<CDRetriggerModel> list = new ArrayList<CDRetriggerModel>();
		for(String appNumebr : appNumberArrayList)
		{
			CDRetriggerModel n1 = new CDRetriggerModel();
			n1.setAppNo(appNumebr);
			n1.setCategory("BPM");
			n1.setStatus("Yes");
			n1.setRemarks("Processed Successfully");
			
			list.add(n1);
		}
		
		CDCaseRetriggerResponse response = new CDCaseRetriggerResponse();

		
		
//		list = null;
		System.out.println(list);
		
		if (Optional.ofNullable(list).isPresent()) {
			
			response.setCdCaseRetriggerResponseList(list);
		}else {
			throw new UserDefinedException(102,"Data not found!");
		}

		return response;
	}
	
}
