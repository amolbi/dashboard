package com.bsli.dashboard.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.dashboard.model.CDCaseRetriggerRequest;
import com.bsli.dashboard.model.CDCaseRetriggerResponse;
import com.bsli.dashboard.model.CaseTrackerDetailsResponse;
import com.bsli.dashboard.model.CaseTrackerListRequest;
import com.bsli.dashboard.model.CaseTrackerRequest;
import com.bsli.dashboard.model.RetryServiceResponse;
import com.bsli.dashboard.service.CaseTrackerService;
import com.bsli.dashboard.service.RestAPICallerService;

@RestController
@CrossOrigin(origins = "http://10.155.10.94:8080") //http://liissuancewfuat.insideabc.com:8080")
@RequestMapping("/case-tracker")
public class CaseTrackerServiceController {
	private final Logger logger = LoggerFactory.getLogger(CaseTrackerServiceController.class);
	
	@Autowired
	private CaseTrackerService caseTrackerService;
	
	@PostMapping("/case-details")
	public ResponseEntity<CaseTrackerDetailsResponse> getCaseDetails(@RequestBody CaseTrackerRequest caseTrackerRequest) {
		logger.info("Service Called with Input -->" + caseTrackerRequest);
		return new ResponseEntity<CaseTrackerDetailsResponse>(caseTrackerService.getCaseDetails(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping("/case-time-taken")
	public ResponseEntity<CaseTrackerDetailsResponse> getAuditHistory(@RequestBody CaseTrackerRequest caseTrackerRequest) {
		logger.info("Service Called with Input -->" + caseTrackerRequest);
		return new ResponseEntity<CaseTrackerDetailsResponse>(caseTrackerService.getCaseTImeTakenDetails(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping("/case-audit-log")
	public ResponseEntity<CaseTrackerDetailsResponse> getAuditLogs(@RequestBody CaseTrackerRequest caseTrackerRequest) {
		logger.info("Service Called with Input -->" + caseTrackerRequest);
		return new ResponseEntity<CaseTrackerDetailsResponse>(caseTrackerService.getCaseAuditLogDetails(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping("/case-tracker-list")
	public ResponseEntity<CaseTrackerDetailsResponse> getCaseTrackerTableList(@RequestBody CaseTrackerListRequest caseTrackerRequest) {
		return new ResponseEntity<CaseTrackerDetailsResponse>(caseTrackerService.getCaseTrackerTableDetails(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping("/case-retry")
	public ResponseEntity<RetryServiceResponse> doCaseRetry(@RequestBody CaseTrackerRequest caseTrackerRequest) {
		return new ResponseEntity<RetryServiceResponse>(caseTrackerService.doCaseRetryService(caseTrackerRequest), HttpStatus.OK);
	}
	
	@PostMapping("/cd-case-retrigger")
	public ResponseEntity<CDCaseRetriggerResponse> doCDCaseRetrigger(@RequestBody CDCaseRetriggerRequest appNumberObj) {
		String appNumbers = appNumberObj.getAppNumbers();
		return new ResponseEntity<CDCaseRetriggerResponse>(caseTrackerService.doCDCaseRetrigger(appNumbers), HttpStatus.OK);
	}

}
