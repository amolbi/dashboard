package com.bsli.caseDetails.service;


import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bsli.caseDetails.controller.CaseDetailsEntity;
import com.bsli.caseDetails.controller.CaseDetailsRepositiry;
import com.bsli.caseDetails.controller.CaseDetailsRequest;
import com.bsli.caseDetails.controller.CaseDetailsResponse;
import com.bsli.caseDetails.exception.UserDefinedException;

@Service
public class CaseDetailsService {

	/*@Autowired
			private CaseDetailsRepositiry casedetailsrepository;
          public CaseDetailsResponse getCaseDetails(CaseDetailsRequest casedetailsRequest){
					List<CaseDetailsEntity> findbycaseid  = casedetailsrepository.findbycaseid(id);
				if (Optional.ofNullable(findbycaseid).isPresent()) {
					CaseDetailsResponse CaseDetailsResponse = new CaseDetailsResponse();
					CaseDetailsResponse.setCaseDetails(findbycaseid);
					return CaseDetailsResponse;
				}
			else {
					throw new UserDefinedException(104,"Case Details are not available");
			
				}
			}*/
/*	@Autowired
	private CaseDetailsRepositiry casedetailsrepository;
	    public CaseDetailsResponse getCaseDetails(long id) {
	    	List<CaseDetailsEntity> findbycaseid =  casedetailsrepository.findbycaseid(id);
	    	if (Optional.ofNullable(findbycaseid).isPresent()) {
				CaseDetailsResponse CaseDetailsResponse = new CaseDetailsResponse();
				CaseDetailsResponse.setCaseDetails(findbycaseid);
				return CaseDetailsResponse;
			}
		else {
				throw new UserDefinedException(104,"Case Details are not available");
		
			}
	    
		}	*/

	public CaseDetailsResponse findbycaseid(Long id) {

//        return CaseDetailsRepositiry.findbycaseid(id);
		return null;
    }

}
