package com.bsli.caseDetails.controller;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CaseDetailsRepositiry extends JpaRepository<CaseDetailsEntity, Integer> {

	 public  List<CaseDetailsEntity> findbycaseid(Long id);

}