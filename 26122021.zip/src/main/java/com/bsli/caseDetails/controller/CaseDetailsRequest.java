package com.bsli.caseDetails.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseDetailsRequest {

		private String searchValue;

		public boolean isValid() {
			return  null != this.searchValue;
		}
		
		public boolean isEmpty() {
			return  !"".equalsIgnoreCase(searchValue);
		}
	}


