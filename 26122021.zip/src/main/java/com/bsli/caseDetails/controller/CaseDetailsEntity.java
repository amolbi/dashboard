package com.bsli.caseDetails.controller;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "V_UI_CASE_TRACKER_DETAILS", schema = "UI")
public class CaseDetailsEntity {

	@Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	private String caseId;
	private String appNo;
	private String appSource;
	private String applicationSync;
	private String payAckNo;
	private String ddupInd;
	private String clientId;
	private String artivatic;
	private String auraStatus;
	private String iqcDecision;
	private String policyCreation;
	private String policyNo;
	private String rwsIngeniumSyc;
	private String mmFlag;
	private String pivcFlag;
	private String aisFlag;
	private String policyIssuance;	
}
