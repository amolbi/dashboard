package com.bsli.caseDetails.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bsli.caseDetails.service.CaseDetailsService;


@RestController
@CrossOrigin("http://10.155.10.94:8080")
@RequestMapping("/case-details")
public class CaseDetailsController {
	
	@Autowired
	private CaseDetailsService casedetailsService;

	@RequestMapping("/case-details/{id}")
	public ResponseEntity<CaseDetailsResponse> getCaseDetails(@PathVariable long id){
		return new ResponseEntity<CaseDetailsResponse>(casedetailsService.findbycaseid(id), HttpStatus.OK);
	}
}